# Creator Anime One - Fixed GitHub DB

File ini adalah versi perbaikan dari `index.html` yang kamu kirim.

## Perbaikan utama

1. Nama member absen tidak lagi ditulis langsung di `index.html`.
2. Daftar nama member dipindah ke:

   `data/members.json`

3. Sistem absen sekarang membaca database member lewat:

   `fetch("data/members.json?v=1")`

4. Typo "hubgungin" sudah diperbaiki menjadi "hubungi".
5. Bagian absen ditambah catatan keamanan:
   website tidak meminta password, OTP, atau login TikTok.
6. Duplikat nama di database member sudah dibersihkan.

## Cara tambah member absen

Buka file:

`data/members.json`

Lalu tambahkan nama baru seperti ini:

```json
{
  "name": "NamaMemberBaru",
  "status": "active"
}
```

Contoh:

```json
{
  "type": "creatoranimeone_member_db",
  "description": "Database nama member yang diizinkan untuk absen di website Creator Anime One.",
  "updatedAt": "2026-06-20",
  "members": [
    { "name": "Ridhz", "status": "active" },
    { "name": "Xyzoo", "status": "active" }
  ]
}
```

## Cara upload ke GitHub

1. Upload `index.html` versi ini ke repository website.
2. Upload folder `data`.
3. Pastikan file ini ada:

   `data/members.json`

4. Commit perubahan.
5. Tunggu GitHub Pages deploy.
6. Buka:

   `https://creatoranimeone.my.id/data/members.json`

Kalau JSON muncul, berarti GitHub DB sudah kebaca.

## Catatan penting

GitHub DB berbentuk JSON tetap bisa dibuka publik lewat browser.
Jadi jangan simpan password, nomor pribadi, token rahasia, atau data sensitif di file JSON.
Untuk data rahasia, pakai backend seperti Firebase dengan rules yang benar, Supabase, atau server sendiri.
